#!/usr/bin/env python3

import glob
import argparse
import os
import re
import datetime

# This function examines the information in the MAF and VCF file formats and looks for conflicts or missing data.
def compare_vcf2maf(invcffile, maffile):
    comparing = "Comparing {} and {}".format(os.path.basename(invcffile),os.path.basename(maffile))
        
    invcf={}
    invcfcount = 0
    with open(invcffile, "r") as fh:
        for line in fh:
            if line.startswith("##"):
                continue
            elif line.startswith("#CHROM"):
                headers = line.split()
                continue 
            else:
                invcfcount += 1
                linedata = line.split()
                invcf["{}-{}".format(linedata[0], linedata[1])] = dict(zip(headers,linedata))
    #             print(invcf["{}-{}".format(linedata[0], linedata[1])])
            
    maf={}
    with open(maffile, "r") as fh:
        for line in fh:
            if line.startswith("#"):
                continue
            elif line.startswith("Hugo_Symbol"):
                headers = line.split()
            else:
                linedata = line.split()
                maf["{}-{}".format(linedata[4], linedata[5])] = dict(zip(headers,linedata))
    #             print(maf["{}-{}".format(linedata[4], linedata[5])])
                
    result = []
    for k,d in invcf.items():
        if k not in maf.keys():
            result.append("CHROM-LOC '{}' missing in maf".format(k))
            continue
    
        if invcf[k]["REF"] != maf[k]["Reference_Allele"]:
            result.append("({}) REF MISMATCH (vcf)'{}' v (maf)'{}'".format(
                k, invcf[k]["REF"], maf[k]["Reference_Allele"] ))
            continue
    
        if invcf[k]["ALT"] != maf[k]["Tumor_Seq_Allele2"]:
            result.append("({}) ALT MISMATCH (vcf)'{}' v (maf)'{}'".format(
                k,invcf[k]["ALT"],maf[k]["Tumor_Seq_Allele2"] ))
            continue
        
    if result == []: 
        result = "(OK) ({} variants)".format(invcfcount, comparing)
    
    result = "{} {}".format(str(result), comparing)

    return result
        
# Execute the main program
if __name__ == "__main__":
    # Create an argument parser object
    parser = argparse.ArgumentParser(description='Validation VCF input file to MAF output file.')
    # Define a command-line argument
    parser.add_argument('--datadir', action="store", dest = "datadir", required = True, 
                        help = "Folder containing both of the input-output data. ")
    parser.add_argument('--vcfdir', action="store", dest = "vcfdir", required = True, 
                        help = "Folder containing the VCF files.")
    parser.add_argument('--mafdir', action="store", dest = "mafdir", required = True, 
                        help = "Folder containing the MAT files.")

    # Parse the arguments and retrieve as a dictionary
    args = vars(parser.parse_args())

    # Get the current date
    current_date = datetime.datetime.now().strftime("%d-%m-%Y")

    # Define the output file name with the current date
    output_file = "{}/validate_vcf2maf_{}.out".format(args["datadir"], current_date)

    # Redirect the output to the file
    with open(output_file, "w") as f:
        for vcfpath in glob.iglob(os.path.join(args["vcfdir"], "*.stdzd.vcf")):
            vcffile = os.path.basename(vcfpath)  # Extract PID from the vcfpath
            PID = vcffile.split(".")[0]
            expected_vep_vcf = f"{PID}.stdzd.vep.vcf"
            if expected_vep_vcf not in os.listdir(args["vcfdir"]):
                f.write("(VEP missing) Output VEP file for VCF infile '{}' does not exist! vcf2maf appears to encounter a VEP annotation error.\n".format(vcffile))
            maffile = vcffile.replace(".stdzd.vcf", ".maf")
            mafpath = os.path.join(args["mafdir"], maffile)
            if not os.path.isfile(mafpath):
                f.write("(MAF missing) Output MAF file for VCF infile '{}' does not exist! vcf2maf appears to have failed.\n".format(vcffile))
                continue 
            # Call the compare function
            result = compare_vcf2maf(vcfpath, mafpath)
            f.write(result + '\n')
 