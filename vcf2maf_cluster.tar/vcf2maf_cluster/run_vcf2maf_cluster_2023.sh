#!/bin/bash

# Define the usage guide
usage() {
    echo "NAME"
    echo "  run_vcf2maf_cluster_2023.sh - Execute the bash file and run the vcf2maf.pl script for the conversion of a VCF file to a MAF file."
    echo ""
    echo "SYNOPSIS"
    echo "  run_vcf2maf_cluster_2023.sh --help"
    echo "  run_vcf2maf_cluster_2023.sh --datadir \"/path/to/datadir\" --vcfdir \"/path/to/datadir/raw_vcf\" --vcf2mafdir \"/path/to/vcf2maf-1.6.21\" --ref_fasta \"/path/to/.vep/homo_sapiens/109_GRCh38/Homo_sapiens.GRCh39.dna.toplevel.fa.gz\" --vep_path \"/path/to/miniconda3/bin\" --vep_data \"/path/to/.vep\""
    echo ""
    echo "OPTIONS"
    echo "  --h, --help  Shows this help message and exit"
    echo "  --datadir    Folder containing both the input and output data."
    echo "  --vcfdir     Path to input file in VCF format."
    echo "  --vcf2mafdir Folder containing the vcf2maf script."
    # E.g: /home/ad.dkfz-heidelberg.de/q874n/softwares/vcf2maf-1.6.21
    # E.g: $HOME/softwares/vcf2maf-1.6.21
    echo "  --ref_fasta  Reference FASTA file."
    # E.g: /home/ad.dkfz-heidelberg.de/q874n/softwares/vep96_GRCh37/homo_sapiens/96_GRCh37/Homo_sapiens.GRCh37.dna.toplevel.fa.gz
    # E.g: $HOME/softwares/vep96_GRCh37/homo_sapiens/96_GRCh37/Homo_sapiens.GRCh37.dna.toplevel.fa.gz
    echo "  --vep_data   VEP's base cache/plugin directory."
    # E.g: $HOME/softwares/vep96_GRCh37
    echo ""
}

# Check if no arguments are provided or --help is specified
if [[ $# -eq 0 ]] || [[ $1 == "--help" ]] || [[ $1 == "--h" ]]; then
    usage
    exit 0
fi

# Parse the command-line arguments
while [[ $# -gt 0 ]]; do  # Check if the number of command-line arguments `$#` is greater than 0. `$#` is a special shell variable that holds the number of command-line arguments passed to a script or function.
    key="$1"
    case $key in # Match the value of the variable $key against different patterns or cases.
        --datadir)
            datadir="$2"
            shift # Discard the current key and its associated value, allowing the loop to move to the next pair of arguments.
            shift
            ;;
        --vcfdir)
            vcfdir="$2"
            shift
            shift
            ;;
        --vcf2mafdir)
            vcf2mafdir="$2"
            shift
            shift
            ;;
        --ref_fasta)
            ref_fasta="$2"
            shift
            shift
            ;;
        --vep_path)
            vep_path="$2"
            shift
            shift
            ;;
        *)
            usage
            exit 1
            ;;
    esac
done

# Check if the required arguments are provided by `-z` flag 
if [[ -z $datadir ]] || [[ -z $vcfdir ]] || [[ -z $vcf2mafdir ]] || [[ -z $ref_fasta ]] || [[ -z $vep_path ]] || [[ -z $vep_data ]]; then
    usage
    exit 1
fi

echo ""
echo "Execute the bash file and run the vcf2maf.pl script for the conversion of a VCF file to a MAF file."
echo ""

# The `set -x` command is used to enable the shell's debugging mode. 
# When this command is executed, the shell starts printing each command it executes along with their arguments and the results of variable substitutions.
set -x

# The VCF files are downloaded from the cluster and executed on the local machine using the code below. 
# Four installed modules must be loaded if you want to run in a cluster.
module describe requirement_vcf2maf
module load SAMtools/1.15-foss-2020a
module load BCFtools/1.9-foss-2017a
module load HTSlib/1.15.1-GCC-9.3.0
module load Perl/5.28.0-GCCcore-7.3.0
module load Python/3.10.4-GCCcore-11.3.0
module load VEP/96.0-foss-2017a-Perl-5.24.2


# Download the VCF files from the cluster
# rsync -avz q874n@b06x-cnt3:/omics/groups/OE0290/internal/cbioportal_testing/cohort_analysis/vcf2maf/stdvcf $vcfdir

# Ensure the directories exist
mkdir -p $datadir/MAFfiles
mkdir -p $datadir/LSFscripts
mkdir -p $datadir/output_error

cd  $vcfdir 

find  $vcfdir -name "*.stdzd.vcf" | while read -r file; do
    if [ -f "$file" ]; then
        dir=$(dirname "$file") # Print the directory of each file
        PID=$(basename "$file" .stdzd.vcf) # Print the ID of each file
        echo "Found STDZD VCF file: $dir/$PID.stdzd.vcf, ID: $PID"

        STDVCFINFILE="${dir}/${PID}.stdzd.vcf"

        BATCHINFILE="$datadir/LSFscripts/${PID}_batch.sh"

        ERRORFILE="$datadir/output_error/${PID}_batch.err"

        OUTFILE="$datadir/output_error/${PID}_batch.out"
        
        sleep 10
         
# A batch file is a script or a text file that contains a sequence of commands or instructions to be executed by a computer's command-line interpreter or shell. 
# It allows you to automate repetitive tasks or execute a series of commands in a specific order
        # Create the batch file
        cat <<EOT > "$BATCHINFILE"
#!/bin/bash

cd $vcf2mafdir

## execute program
perl vcf2maf.pl \
  --input-vcf "$STDVCFINFILE" \
  --output-maf "$datadir/MAFfiles/$PID.maf" \
  --tumor-id "$PID" \
  --normal-id "$PID" \
  --ref-fasta "$ref_data" \
  --vcf-tumor-id TUMOR \
  --vcf-normal-id CONTROL \
  --vep-path "$vep_path" \
  --vep-data "$vep_data" \
  --vep-overwrite \
  --verbose \
  1>"$OUTFILE" 2>"$ERRORFILE"
EOT

        # Make the batch file executable
        chmod +x "$BATCHINFILE"

        # Execute the batch file using Bash
        bash "$BATCHINFILE"
        echo "Executed batch file for $PID"
    fi
done

echo "Done."

sleep 10

echo ""
echo "Validate VCF input file to MAF output file and redirect the output to the file"

python $datadir/validate_vcf2maf_2023.py --datadir $datadir --vcfdir $vcfdir --mafdir $datadir/MAFfiles 

# Upload the output result to a cluster. 
# rsync -avz $datadir q874n@b06x-cnt3:/output
